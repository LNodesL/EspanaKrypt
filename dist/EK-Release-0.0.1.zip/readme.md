# EspanaKrypt

Drag & drop any valid PE into EspanaKrypt.exe in your file explorer to crypt the file. For testing, the helloworld.exe file has been provided to you.

A terminal window will appear with a log of information. Upon success, your original PE has been encrypted and is ready. 

Press Enter to continue & close the terminal window. Armada.exe will be created for you, which is the final program. Opening this will also open your original PE that you dropped into EspanaKrypt in the first step.

## Command Line Interface

You may use EspanaKrypt CLI like so:

```
./EspanaKrypt.exe originalProgram.exe
```